# Covid Landing Page

Responsive covid landing page created with HTML, CSS and JavaScript.
The page we are building is to help raise awareness and prevention for covid-19.

Live preview [Covid landing page](https://covid-landing-page-seven.vercel.app/)

# Tech Stack

- HTML
- CSS
- JavaScript

## What it does
It's a informative website for awaring peoples from covid, It's preety good looking too.

# Section
- Banner
- what is section
- cotagion
- symptoms section
- what should you do section
- contact section
- footer

# Preview
![Covid Landing Page - Google Chrome 08-01-2023 10 36 30 PM](https://user-images.githubusercontent.com/95171638/211209684-e042c7ba-9fc0-4c5d-bb45-46605284ec02.png)
